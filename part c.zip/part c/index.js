const express = require('express');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');
const csv = require("csvtojson");
const sql = require('./db/db');
const CRUD = require('./db/CRUD');
const CRUDdb = require('./db/CRUDdb');
const port = 3000;

// const cookieParser = require("cookie-parser");
// const { read } = require('fs');


app.use(express.static(path.join(__dirname,"static")))
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true
}));

// load view engine
app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'pug');

//home page route
app.get('/', (req,res)=>{
    res.redirect('/home');
});
app.get('/home', (req,res)=>{
    res.render('home');
});

//profile route
app.get('/my_profile', (req,res)=>{
        res.render('my_profile');
    });

//login route
app.get('/page2', (req,res)=>{
        res.render('page2');
    });

app.post('/loginData', CRUD.checkUser);


//sign up route
app.get('/page3', (req,res)=>{
        res.render('page3');
    });

app.post('/signUp', CRUD.insertNewAccount);

//delete user route
app.get('/delete_user', (req,res)=>{
    res.render('delete_user');
});

app.post('/deleteAccount', CRUD.deleteAccount);

//search route
app.get('/page4', (req,res)=>{
        res.render('page4');
    });
        
// app.get('/page5', (req,res)=>{
//         res.render('showAll', {
//             V1: 'click button to select all from customers',
//         });
//     });


//about route
app.get('/page6', (req,res)=>{
        res.render('page6');
    });


app.post('/findStores', async (req,res)=>{
    // validate body exists
    if (!req.body) {
        res.status(400).send({message: "p???????"});
        return;    
    }
    console.log(JSON.stringify(req.body))
    var type = req.body.type;
    var region = req.body.region;
    var friday = req.body.friday;

    var [stores] = await CRUD.findStores(type, region, friday)
        
    res.render('results', {
        stores: stores
    })
    }
)


//--------------------////////////initialize db////////////-------------------------

// create tables 
app.get('/createUsersTable', CRUDdb.createUsersTable);
app.get('/createStoresTable', CRUDdb.createStoresTable);

//insert data
app.get('/DataToUsersTable', CRUDdb.DataToUsersTable);
app.get('/DataToStoresTable', CRUDdb.DataToStoresTable);


//show tables
app.get('/show_all_stores', CRUD.showAllStores);
app.get('/ShowUsersTable', CRUDdb.ShowUsersTable);
app.get('/ShowStoresTable', CRUDdb.ShowStoresTable);


//drop tables
// app.get('/dropUsersTable', CRUDdb.dropUsersTable);
// app.get('/dropStoresTable', CRUDdb.dropStoresTable);
app.get('/dropDBtables', [CRUDdb.dropUsersTable, CRUDdb.dropStoresTable]);

// set server to listen at port
app.listen(3000, ()=>{
console.log("pug , Server is running on port "+port)
});