const sql = require('./db');
const path = require("path");

const checkUser = (req, res)=>{
    if (!req.body) { 
        res.status(400).send({message: "Content can not be empty!"});
        return;
    }
    const userData = {
        "email": req.body.email,
        "password": req.body.password
    };
    console.log(userData.email, userData.password);

    sql.query("SELECT email, password FROM users where email like ?", userData.email + "%", (err, mysqlres) => {
        if (err) {
            console.log("error: ", err);
            res.status(400).send({message: "error: " + err});
            return;
        }
        console.log(mysqlres);
        if (mysqlres.length == 0) {
            res.render('page2',{
                email_err: 'wrong email, please try again'
            });
            return;
        }
        else {
            if (mysqlres[0].password == userData.password) {
                // res.redirect("/setEmailCookie/" + mysqlres[0].email);
                res.redirect('/my_profile');
                return;
            } else {
                res.render('page2', {
                    pass_err: 'wrong password, please try again'
                });
                return;
            }
        }
    });
};



const insertNewAccount = (req, res)=>{
    if (!req.body) {
        res.status(400).send({message: "Content can not be empty!"});
        return;
    }
    const NewSignUp = {
        "name": req.body.name,
        "email": req.body.email,
        "password": req.body.password
    };
    sql.query("select * from users where name like ?", req.body.name + "%", (err, mysqlres) =>{
        if (err) {
            console.log("error: ", err);
            res.status(400).send({message: "error: " + err});
            return;
        }
        else if (mysqlres.length == 0) {
                sql.query("INSERT INTO users SET ?", NewSignUp, (err, mysqlres2) => {
                    if (err) {
                        console.log("error: ", err);
                        res.status(400).send({message: "error in create user: " + err + NewSignUp});
                        return;
                    }
                    console.log("created new user");
                    res.redirect('/page2');
                    return;
                });
                return;

        } else {
            res.render('page3', {
                name_err: "this username is already taken",
            });
            return;
        }
        })
}



//deleteAccount

const deleteAccount = (req, res) => {
    if (!req.body) {
        res.status(400).send({message: "Content can not be empty!"});
        return;
    }
    const Account = {
        "email": req.body.email,
        "password": req.body.password
    };
    sql.query("DELETE FROM users WHERE email = ? and password = ?", [Account.email, Account.password], (err, mysqlres) => {
        if (err) {
            console.log("error: ", err);
            res.status(400).send({message: "error: " + err});
            return;
        }
        else {
                console.log("the user:" + [Account.email, Account.password] +"was deleted");
                res.render('page3', {
                delete_msg: "account was deleted"
                });
                return;
            }}
        )};



const findStores = (type, region, friday) => {
    console.log(type)
    console.log(region)
    console.log(friday)
    return sql.promise().query("SELECT store_name, address, opening, link FROM stores Where type = ? And region = ? And friday = ?",[type, region,friday])
}
    
    

const showAllStores = (req,res)=>{
    const storedata = {
        "type": req.body.type,
        "region": req.body.region
    };
    sql.query("SELECT store_name, address, opening, link FROM stores Where type = ? And region = ?",[storedata.type, storedata.region], (err, mysqlres) => {
        if (err) {
        console.log("error: ", err);
        res.status(400).send({message: "error in getting all stores: " + err});
        return;
        };
        console.log("got all stores...");
        // res.send(mysqlres);
        // const t= new Date();
        res.render('results',{
            stores: mysqlres
        })
        return;
})
};

module.exports = {findStores,showAllStores,checkUser,insertNewAccount,deleteAccount};