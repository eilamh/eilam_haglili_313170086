const sql = require('./db')
const path = require("path");
const csv = require("csvtojson");


//create tables
const createUsersTable = (req,res)=>{
    var Q1 = "CREATE TABLE IF NOT EXISTS users (id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,name varchar(255) not null, email varchar(255) not null, password varchar(255) not null) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
    sql.query(Q1,(err,mysqlres)=>{
        if (err) {
            console.log("error ", err);
            res.status(400).send({message: "error in creating users table"});
            return;
        }
        console.log('Users Table created successfully');
        res.render('index', {
            V1:"Users Table created"
        });
        return;
    })
};

const createStoresTable = (req,res)=>{
    var Q3 = "CREATE TABLE IF NOT EXISTS stores (store_name varchar(255) primary key, address varchar(255) not null, opening varchar(255) not null, link varchar(255) not null, type varchar(255) not null, region varchar(255) not null, friday varchar(255) null) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
    sql.query(Q3,(err,mysqlres)=>{
        if (err) {
            console.log("error ", err);
            res.status(400).send({message: "error in creating stores table"});
            return;
        }
        console.log('stores table created successfully');
        //add
        res.send("stores tables created");
        return;
    })
};

//insert data to tables 

const DataToUsersTable = (req,res)=>{
    const csvFilePath= path.join(__dirname, "users.csv");
    csv()
    .fromFile(csvFilePath)
    .then((jsonObj)=>{
    console.log(jsonObj);
    jsonObj.forEach(element => {
        var NewEntry = {
            "name": element.name,
            "email": element.email,
            "password": element.password
        }
        sql.query("INSERT INTO users SET ?", NewEntry, (err,mysqlres)=>{
            if (err) {
                console.log("error in inserting data", err);
            }
            console.log("created row sucssefuly ");
        });
    });
    });
    res.send("users data inserted");
};

const DataToStoresTable = (req,res)=>{
    const csvFilePath= path.join(__dirname, "stores.csv");
    csv()
    .fromFile(csvFilePath)
    .then((jsonObj)=>{
    console.log(jsonObj);
    jsonObj.forEach(element => {
        var NewEntry = {
            "store_name": element.store_name,
            "address": element.address,
            "opening": element.opening,
            "link": element.link,
            "type": element.type,
            "region": element.region,
            "friday": element.friday
        }
        sql.query("INSERT INTO stores SET ?", NewEntry, (err,mysqlres)=>{
            if (err) {
                console.log("error in inserting data", err);
            }
            console.log("created row sucssefuly ");
        });
    });
    });
    res.send("stores data inserted");
};

//drop tables

const dropUsersTable = (req,res,next)=>{
    sql.query("DROP TABLE users", (err, mysqlres)=>{
        if (err) {
            console.log("error in dropping users table ", err);
            res.status(400).send({message: "error in dropping users table" + err});
            return;
        }
        console.log("users table dropped");
        return;
    });
    next();
};

const dropStoresTable = (req,res)=>{
    sql.query("DROP TABLE stores", (err, mysqlres)=>{
        if (err) {
            console.log("error in dropping stores table ", err);
            res.status(400).send({message: "error in dropping stores table" + err});
            return;
        }
        console.log("stores table dropped");
        return;
    });
};

//show tables

const ShowUsersTable = (req,res)=>{
    sql.query("SELECT * FROM users", (err, mySQLres)=>{
        if (err) {
            console.log("error in showing users table ", err);
            res.send("error in showing users table ");
            return;
        }
        console.log("showing users table");
        res.send(mySQLres);
        return;
    })
};

const ShowStoresTable = (req,res)=>{
    sql.query("SELECT * FROM stores", (err, mySQLres)=>{
        if (err) {
            console.log("error in showing stores table ", err);
            res.send("error in showing stores table ");
            return;
        }
        console.log("showing stores table");
        res.send(mySQLres);
        return;
    })
};

module.exports = {createUsersTable,createStoresTable, 
                DataToUsersTable, DataToStoresTable, 
                dropUsersTable, dropStoresTable,
                ShowUsersTable, ShowStoresTable};